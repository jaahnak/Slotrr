# SLOTRR - Classroom Booking System

A comprehensive classroom booking system built with Python and Tkinter, featuring a beautiful GUI and Supabase backend.

## Features

- **Role-based Access**: Admin, Teacher, and Student roles
- **Beautiful Tkinter UI**: Custom-styled interface with dark/light themes
- **Real-time Booking**: Check availability and book classrooms instantly
- **Email Notifications**: Automatic emails to students and admins
- **Campus Map**: Visual representation of classroom availability
- **Reports & Analytics**: Booking statistics and reports
- **Session Management**: Persistent login sessions

## Installation

```bash
pip install slotrr
```

## Setup

1. Create a Supabase project and get your URL and anon key
2. Set up environment variables:
   ```bash
   export SUPABASE_URL="your_supabase_url"
   export SUPABASE_ANON_KEY="your_anon_key"
   export SMTP_USERNAME="your_email@gmail.com"
   export SMTP_PASSWORD="your_app_password"
   ```
3. Run the database migrations (create tables as per the schema in the code)
4. Launch the app:
   ```bash
   slotrr
   ```

## Database Schema

The app uses Supabase with the following tables:
- `users`: User accounts with roles
- `classrooms`: Room information
- `bookings`: Booking records
- `booking_students`: Many-to-many relationship for students in bookings

## Usage

- **Admin**: Manage rooms, users, bookings, view reports
- **Teacher**: Book classrooms and view own bookings
- **Student**: Receive email notifications (no login required)

## Development

Clone the repo and install dependencies:

```bash
git clone <repo-url>
cd slotrr
pip install -r requirements.txt
python -m slotrr.main
```

## License

MIT License